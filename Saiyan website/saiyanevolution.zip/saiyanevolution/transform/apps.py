from django.apps import AppConfig


class TransformConfig(AppConfig):
    name = 'transform'
