from django.apps import AppConfig


class DigitAppConfig(AppConfig):
    name = 'digit_app'
